<?php
namespace App\Controllers;

class Ktp extends BaseController
{
    public function index()
    {
        return view('profil');
    }
}